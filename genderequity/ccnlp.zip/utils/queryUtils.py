import cx_Oracle
import datetime
import gc
import pandas as pd
import time
from typing import Iterable

# map partition number to server name
partition_db_map = {
    1 : "idsdb01", 2 : "idsdb02", 3 : "boudb03",
    4 : "boudb02", 5 : "idsdb03", 6 : "idsdb04",
    7 : "boudb01", 8 : "boudb04"}

def queryPartitions(queryString: str,
                    userName: str, password: str, 
                    maxDaysAgo: int=2,
                    partitions: Iterable[int]=[1, 2, 3, 4, 5, 6, 7, 8],
                    verbose: bool=True) -> pd.DataFrame:
    """
    TODO (mranger): add integration tests for this method

    maps query to multiple partitions
    and concatenates the results to a single pd.DataFrame

    The string "{0}" should be used in the query to refer to partition number in the query
    eg. "select * from prodacquisio{0}nonstat.adwtextad" will map to several partitions

    The string :cutoff should be used for datelimits in the query
    This will be limited by the maxDaysAgo param
    eg. "where adwtext.TRG_LASTUPDATEDON > :cutoff"  
        with maxDaysAgo=2 will query in the last 2 days for that column

    Note this method has a maximum RAM usage of 2x the result (at the concatenation stage)

    :param queryString: the oracle server query. 
                        Include {0} where it should be mapped to partitions 
                        (eg. in table names)
    :param userName: username in the oracle DB
    :param password: password for the username in DB
    :param maxDaysAgo: number of days to look back in the query.
                       use :cutoff in the query WHERE clause to refer to this date limitation
    :param partitions: list of partitions you want to map the query to
    :param verbose: whether to print timing output or not

    :type queryString: str
    :type userName: str
    :type password: str
    :type maxDaysAgo: int
    :type partitions: Iterable[int]
    :type verbose: bool

    :return: the concatenated query for all partitions
    :rtype: pd.DataFrame
    """

    if type(partitions) == int:
        partitions = [partitions]
    assert max(partitions) < 9, "Partitions should be in {1->8}"
    assert min(partitions) > 0, "Partitions should be in {1->8}"

    datelimit = datetime.datetime.today() - datetime.timedelta(days=maxDaysAgo)

    partition_cx = {}
    for i in range(1, 9):
        partition_cx[i] = cx_Oracle.connect(
            user=userName,
            password=password,
            dsn="""
                (DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST={1})(PORT=1521))
                (CONNECT_DATA=(SERVER=DEDICATED)
                (SERVICE_NAME=acquisio{0}.clientcampaigns.com)
                (INSTANCE_NAME = acquisio{0})))
                """.format(str(i), partition_db_map[i]),
            threaded=False)

    df_list = [] # query result list to concat together
    for partition in partitions:
        if verbose:
            print("Partition {0} query".format(partition))
        start_time = time.time()
        try:
            df_list.append(
                pd.read_sql(
                    queryString.format(partition),
                    partition_cx[partition],
                    params={"cutoff" : datelimit}
                )
            )
        # ADS database has some agencies not in Oracle
        # We pass on those if we get a DB error
        except IOError as e:
            if verbose:
                print("\n\n------ERROR------\n\n", e)
            pass
        gc.collect() # GC call to guarantee max RAM usage
        if verbose:
            print("time: {0}sec".format(
                  int(time.time() - start_time)))
    # Merge accounts in one df
    result = pd.concat(df_list)
    gc.collect()
    if verbose:
        print("Done. (rows: ", len(result), ")")
        print("Columns: ", ', '.join(list(result.columns)))
    return result

